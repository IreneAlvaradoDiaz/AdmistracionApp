export const environment = {
  firebase: {
    projectId: 'cuida-a-mi-mascota-fc036',
    appId: '1:545483916452:web:b86b31ebcdf689a6bad231',
    storageBucket: 'cuida-a-mi-mascota-fc036.appspot.com',
    locationId: 'europe-west',
    apiKey: 'AIzaSyCleCVfALdBiMpQFDCcroDe_jyWHpb9b2Y',
    authDomain: 'cuida-a-mi-mascota-fc036.firebaseapp.com',
    messagingSenderId: '545483916452',
  },
  production: true
};
