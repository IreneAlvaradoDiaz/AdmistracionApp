// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  firebase: {
    projectId: 'cuida-a-mi-mascota-fc036',
    appId: '1:545483916452:web:b86b31ebcdf689a6bad231',
    storageBucket: 'cuida-a-mi-mascota-fc036.appspot.com',
    locationId: 'europe-west',
    apiKey: 'AIzaSyCleCVfALdBiMpQFDCcroDe_jyWHpb9b2Y',
    authDomain: 'cuida-a-mi-mascota-fc036.firebaseapp.com',
    messagingSenderId: '545483916452',
  },
  production: false
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
